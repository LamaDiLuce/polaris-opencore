# Batch Conversion Scripts for macOS and Linux.
These scripts will use `sox` to convert files from `.wav` to `.RAW` for use in the Polaris Anima EVO. Input files need to be named according to either the CFX or Proffie naming schemes.

These scripts assume you have `sox` installed somewhere in your path. You can download `sox` [here](https://sox.sourceforge.net/) and build from source.

For macOS, `sox` is available via [Homebrew](https://brew.sh/) (`brew install sox`). For Linux, it is available in most package repositories (`apt-get install sox` or `yum install sox`).